#parse("Copyright.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("Author.java")
public interface ${NAME} {
}